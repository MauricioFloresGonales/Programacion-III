<?php

echo json_encode($_POST, true); // Peticion

var_dump($FILES); // archivos


?>